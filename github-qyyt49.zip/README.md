# threejs-r3f-tutorial-animations

<img width="1263" alt="image" src="https://user-images.githubusercontent.com/6551176/204001329-2be3eeb3-b243-4a04-a8fe-cb8c3c3f6dc5.png">

Demo

https://codesandbox.io/p/github/wass08/threejs-r3f-tutorial-animations/draft/stoic-scooby?file=%2Fsrc%2FApp.jsx
